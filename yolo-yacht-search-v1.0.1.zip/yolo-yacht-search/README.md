# YOLO Yacht Search & Booking Plugin

WordPress plugin for YOLO Charters with Booking Manager API integration, featuring search widget and results with company prioritization.

## Features

✅ **Search Widget** - Yacht search form styled like yolo-charters.com  
✅ **Search Results** - Display results with YOLO boats prioritized  
✅ **Litepicker Integration** - Beautiful date range picker with mobile support  
✅ **Booking Manager API** - Real-time yacht availability from Booking Manager  
✅ **Company Prioritization** - YOLO boats (7850) shown first, then partner companies  
✅ **Database Caching** - Configurable cache duration for API responses  
✅ **Admin Settings** - Easy configuration via WordPress admin panel  
✅ **Responsive Design** - Mobile-friendly interface  
✅ **Easy Shortcodes** - No block editor needed!

## Installation

1. Upload the `yolo-yacht-search` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **YOLO Yacht Search** in the admin menu to configure settings

## Quick Setup (3 Steps!)

### Step 1: Configure Settings
1. Go to **YOLO Yacht Search** in WordPress admin
2. All important settings are **already prefilled**:
   - ✅ API Key
   - ✅ My Company ID: 7850 (YOLO)
   - ✅ Friend Companies: 4366, 3604, 6711
3. Click **Save Settings**

### Step 2: Create Results Page
1. Create a new page: **Pages → Add New**
2. Title: "Search Results"
3. In the content editor, add this shortcode:
   ```
   [yolo_search_results]
   ```
4. Publish the page
5. Go back to **YOLO Yacht Search** settings
6. Select "Search Results" in the **Search Results Page** dropdown
7. Save settings

### Step 3: Add Search Widget
1. Edit your homepage (or any page)
2. Add this shortcode to the content:
   ```
   [yolo_search_widget]
   ```
3. Publish the page

**Done!** 🎉

## Shortcodes

### `[yolo_search_widget]`
Displays the yacht search form with:
- Boat type dropdown
- Date range picker (Litepicker)
- Search button

**Usage:**
```
[yolo_search_widget]
```

Add this to your homepage or any page where you want the search form.

### `[yolo_search_results]`
Displays search results with:
- YOLO boats section (highlighted with red badge)
- Partner boats section
- Beautiful yacht cards

**Usage:**
```
[yolo_search_results]
```

Add this to your dedicated search results page.

## How It Works

1. User visits homepage and sees search form
2. Selects boat type and dates
3. Clicks "SEARCH"
4. Gets redirected to results page
5. Plugin fetches boats from Booking Manager API:
   - **YOLO boats** (Company 7850) - displayed FIRST with red badge
   - **Partner boats** (Companies 4366, 3604, 6711) - displayed below
6. Results are cached for 24 hours

## Admin Settings

### API & Company Settings
- **API Key**: Your Booking Manager API key (prefilled)
- **My Company ID**: 7850 (YOLO) - prefilled
- **Friend Companies IDs**: 4366, 3604, 6711 - prefilled
- **Search Results Page**: Select the page with `[yolo_search_results]`

### General Settings
- **Cache Duration**: 1-168 hours (default: 24 hours)
- **Currency**: EUR, USD, or GBP

### Styling Settings
- **Primary Color**: Main theme color (default: #1e3a8a)
- **Button Background**: Search button color (default: #dc2626)
- **Button Text**: Button text color (default: #ffffff)

## Yacht Card Design

Each yacht is displayed in a beautiful card showing:
- 🖼️ Yacht image (or placeholder)
- 📝 Yacht name and type
- 📍 Location/marina
- 💰 Price in large green numbers
- 🔵 "View Details" button

**YOLO boats** have:
- 🔴 Red "YOLO" badge in top-right corner
- 🔴 Red border around the card
- ⭐ Displayed in first section

## Responsive Design

- **Desktop**: 3 yacht cards per row
- **Tablet**: 2 cards per row
- **Mobile**: 1 card full width

## Customization

### Change Colors
Go to **YOLO Yacht Search → Styling Settings** and use the color pickers.

### Custom CSS
Add to your theme's CSS:
```css
/* Change YOLO badge color */
.yolo-ys-yacht-badge {
    background: #your-color !important;
}

/* Change button style */
.yolo-ys-search-button {
    background: #your-color !important;
}
```

### Disable Saturday-Only Booking
Edit `/public/js/yolo-yacht-search-public.js` and modify the `lockDaysFilter` function.

## Troubleshooting

### Shortcode shows as text
- Make sure the plugin is activated
- Check that you're in the page editor, not the code editor

### Search results not showing
1. Verify you selected a Results Page in settings
2. Make sure that page has `[yolo_search_results]` shortcode
3. Check browser console for errors

### No boats found
1. Verify API key is correct
2. Try different date ranges
3. Check Booking Manager API status

## Technical Details

### File Structure
```
yolo-yacht-search/
├── admin/              # Admin settings
├── assets/             # Litepicker JS/CSS
├── includes/           # Core classes
│   ├── class-yolo-ys-shortcodes.php
│   ├── class-yolo-ys-booking-manager-api.php
│   └── ...
├── public/             # Frontend
│   ├── templates/      # Search form & results
│   ├── css/
│   └── js/
└── yolo-yacht-search.php
```

### Requirements
- WordPress 5.8+
- PHP 7.4+
- Active Booking Manager API key

## What's Prefilled

✅ **Booking Manager API Key**: Your full API key  
✅ **YOLO Company ID**: 7850  
✅ **Partner Companies**: 4366, 3604, 6711  
✅ **Cache Duration**: 24 hours  
✅ **Currency**: EUR  
✅ **Primary Color**: #1e3a8a (blue)  
✅ **Button Color**: #dc2626 (red)  

## Support

For issues or questions:
- Email: george@yolocharters.com
- GitHub: https://github.com/georgemargiolos/LocalWP

## License

GPL v2 or later

## Credits

- **Author**: George Margiolos
- **Litepicker**: MIT License
- **Booking Manager API**: MMK Systems

## Changelog

### Version 1.0.1
- Switched to shortcodes (easier to use!)
- No compilation needed
- Improved admin instructions

### Version 1.0.0
- Initial release
