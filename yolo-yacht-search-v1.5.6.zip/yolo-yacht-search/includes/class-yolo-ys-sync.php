<?php
/**
 * Yacht sync functionality
 */
class YOLO_YS_Sync {
    
    private $api;
    private $db;
    
    public function __construct() {
        $this->api = new YOLO_YS_Booking_Manager_API();
        $this->db = new YOLO_YS_Database();
    }
    
    /**
     * Sync all yachts from all companies (WITHOUT prices)
     */
    public function sync_all_yachts() {
        // Increase time limit for sync
        set_time_limit(300); // 5 minutes
        ini_set('max_execution_time', 300);
        
        $results = array(
            'success' => false,
            'message' => '',
            'companies_synced' => 0,
            'yachts_synced' => 0,
            'errors' => array()
        );
        
        // Get company IDs
        $my_company_id = get_option('yolo_ys_my_company_id', 7850);
        $friend_companies = get_option('yolo_ys_friend_companies', '4366,3604,6711');
        $friend_ids = array_map('trim', explode(',', $friend_companies));
        
        // Combine all companies
        $all_companies = array_merge(array($my_company_id), $friend_ids);
        
        foreach ($all_companies as $company_id) {
            if (empty($company_id)) continue;
            
            try {
                // Fetch yachts for this company
                $yachts = $this->api->get_yachts_by_company($company_id);
                
                // Validate response is an array
                if (!is_array($yachts)) {
                    $results['errors'][] = "Company $company_id: Unexpected response format (not an array)";
                    error_log('YOLO YS: Unexpected yacht response for company ' . $company_id);
                    continue;
                }
                
                if (count($yachts) > 0) {
                    foreach ($yachts as $yacht) {
                        $this->db->store_yacht($yacht, $company_id);
                        $results['yachts_synced']++;
                    }
                    $results['companies_synced']++;
                } else {
                    $results['errors'][] = "Company $company_id: No yachts returned";
                }
                
            } catch (Exception $e) {
                $results['errors'][] = "Company $company_id: " . $e->getMessage();
                error_log('YOLO YS: Failed to sync yachts for company ' . $company_id . ': ' . $e->getMessage());
            }
        }
        
        if ($results['yachts_synced'] > 0) {
            $results['success'] = true;
            $results['message'] = sprintf(
                'Successfully synced %d yachts from %d companies',
                $results['yachts_synced'],
                $results['companies_synced']
            );
        } else {
            $results['message'] = 'No yachts were synced. Check errors.';
        }
        
        // Update last sync time
        update_option('yolo_ys_last_sync', current_time('mysql'));
        
        return $results;
    }
    
    /**
     * Sync prices for all companies (SEPARATE OPERATION)
     * Uses chunking by month to avoid timeouts
     */
    public function sync_all_prices() {
        // Increase time limit for sync
        set_time_limit(300); // 5 minutes
        ini_set('max_execution_time', 300);
        
        $results = array(
            'success' => false,
            'message' => '',
            'companies_processed' => 0,
            'prices_synced' => 0,
            'chunks_processed' => 0,
            'errors' => array()
        );
        
        // Get company IDs
        $my_company_id = get_option('yolo_ys_my_company_id', 7850);
        $friend_companies = get_option('yolo_ys_friend_companies', '4366,3604,6711');
        $friend_ids = array_map('trim', explode(',', $friend_companies));
        
        // Combine all companies
        $all_companies = array_merge(array($my_company_id), $friend_ids);
        
        // Sync next 12 weeks in 4-week increments (3 chunks)
        $start = new DateTime();
        $chunks = array();
        
        for ($i = 0; $i < 3; $i++) {
            $dateFrom = clone $start;
            $dateFrom->modify('+' . ($i * 4) . ' weeks');
            
            $dateTo = clone $dateFrom;
            $dateTo->modify('+4 weeks');
            
            $chunks[] = array(
                'dateFrom' => $dateFrom->format('Y-m-d') . 'T00:00:00',
                'dateTo' => $dateTo->format('Y-m-d') . 'T23:59:59'
            );
        }
        
        foreach ($all_companies as $company_id) {
            if (empty($company_id)) continue;
            
            $company_prices = 0;
            
            foreach ($chunks as $chunk) {
                try {
                    $prices = $this->api->get_prices($company_id, $chunk['dateFrom'], $chunk['dateTo']);
                    
                    // Validate response is an array
                    if (!is_array($prices)) {
                        $results['errors'][] = "Company $company_id: Unexpected price response format";
                        error_log('YOLO YS: Unexpected price response for company ' . $company_id);
                        continue;
                    }
                    
                    if (count($prices) > 0) {
                        foreach ($prices as $price) {
                            YOLO_YS_Database_Prices::store_price($price);
                            $company_prices++;
                        }
                    }
                    
                    $results['chunks_processed']++;
                    
                } catch (Exception $e) {
                    $results['errors'][] = "Company $company_id ({$chunk['dateFrom']} to {$chunk['dateTo']}): " . $e->getMessage();
                    error_log('YOLO YS: Failed to sync prices for company ' . $company_id . ': ' . $e->getMessage());
                }
            }
            
            if ($company_prices > 0) {
                $results['companies_processed']++;
                $results['prices_synced'] += $company_prices;
            }
        }
        
        // Delete old prices
        YOLO_YS_Database_Prices::delete_old_prices();
        
        if ($results['prices_synced'] > 0) {
            $results['success'] = true;
            $results['message'] = sprintf(
                'Successfully synced %d prices from %d companies (%d chunks processed)',
                $results['prices_synced'],
                $results['companies_processed'],
                $results['chunks_processed']
            );
        } else {
            $results['success'] = true; // Still success even if no prices found
            $results['message'] = 'Price sync completed. No prices found for the date range.';
        }
        
        // Update last price sync time
        update_option('yolo_ys_last_price_sync', current_time('mysql'));
        
        return $results;
    }
    
    /**
     * Get sync status
     */
    public function get_sync_status() {
        $stats = $this->db->get_sync_stats();
        $last_sync = get_option('yolo_ys_last_sync', null);
        $last_price_sync = get_option('yolo_ys_last_price_sync', null);
        
        return array(
            'total_yachts' => $stats['total_yachts'],
            'yolo_yachts' => $stats['yolo_yachts'],
            'partner_yachts' => $stats['total_yachts'] - $stats['yolo_yachts'],
            'last_sync' => $last_sync,
            'last_sync_human' => $last_sync ? human_time_diff(strtotime($last_sync), current_time('timestamp')) . ' ago' : 'Never',
            'last_price_sync' => $last_price_sync,
            'last_price_sync_human' => $last_price_sync ? human_time_diff(strtotime($last_price_sync), current_time('timestamp')) . ' ago' : 'Never'
        );
    }
}
