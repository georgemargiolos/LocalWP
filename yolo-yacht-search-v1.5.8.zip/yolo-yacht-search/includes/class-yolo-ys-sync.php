<?php
/**
 * Yacht sync functionality
 */
class YOLO_YS_Sync {
    
    private $api;
    private $db;
    
    public function __construct() {
        $this->api = new YOLO_YS_Booking_Manager_API();
        $this->db = new YOLO_YS_Database();
    }
    
    /**
     * Sync all yachts from all companies (WITHOUT prices)
     */
    public function sync_all_yachts() {
        // Increase time limit for sync
        set_time_limit(300); // 5 minutes
        ini_set('max_execution_time', 300);
        
        $results = array(
            'success' => false,
            'message' => '',
            'companies_synced' => 0,
            'yachts_synced' => 0,
            'errors' => array()
        );
        
        // Get company IDs
        $my_company_id = get_option('yolo_ys_my_company_id', 7850);
        $friend_companies = get_option('yolo_ys_friend_companies', '4366,3604,6711');
        $friend_ids = array_map('trim', explode(',', $friend_companies));
        
        // Combine all companies
        $all_companies = array_merge(array($my_company_id), $friend_ids);
        
        foreach ($all_companies as $company_id) {
            if (empty($company_id)) continue;
            
            try {
                // Fetch yachts for this company
                $yachts = $this->api->get_yachts_by_company($company_id);
                
                // Validate response is an array
                if (!is_array($yachts)) {
                    $results['errors'][] = "Company $company_id: Unexpected response format (not an array)";
                    error_log('YOLO YS: Unexpected yacht response for company ' . $company_id);
                    continue;
                }
                
                if (count($yachts) > 0) {
                    foreach ($yachts as $yacht) {
                        $this->db->store_yacht($yacht, $company_id);
                        $results['yachts_synced']++;
                    }
                    $results['companies_synced']++;
                } else {
                    $results['errors'][] = "Company $company_id: No yachts returned";
                }
                
            } catch (Exception $e) {
                $results['errors'][] = "Company $company_id: " . $e->getMessage();
                error_log('YOLO YS: Failed to sync yachts for company ' . $company_id . ': ' . $e->getMessage());
            }
        }
        
        if ($results['yachts_synced'] > 0) {
            $results['success'] = true;
            $results['message'] = sprintf(
                'Successfully synced %d yachts from %d companies',
                $results['yachts_synced'],
                $results['companies_synced']
            );
        } else {
            $results['message'] = 'No yachts were synced. Check errors.';
        }
        
        // Update last sync time
        update_option('yolo_ys_last_sync', current_time('mysql'));
        
        return $results;
    }
    
    /**
     * Sync prices for all companies (SEPARATE OPERATION)
     * Uses chunking by month to avoid timeouts
     */
    public function sync_all_prices() {
        // Increase time limit for sync
        set_time_limit(300); // 5 minutes
        ini_set('max_execution_time', 300);
        
        $results = array(
            'success' => false,
            'message' => '',
            'companies_processed' => 0,
            'prices_synced' => 0,
            'chunks_processed' => 0,
            'errors' => array()
        );
        
        // Get company IDs
        $my_company_id = get_option('yolo_ys_my_company_id', 7850);
        $friend_companies = get_option('yolo_ys_friend_companies', '4366,3604,6711');
        $friend_ids = array_map('trim', explode(',', $friend_companies));
        
        // Combine all companies
        $all_companies = array_merge(array($my_company_id), $friend_ids);
        
        // Determine the next peak season (May-September)
        $now = new DateTime();
        $current_year = (int)$now->format('Y');
        $current_month = (int)$now->format('n');
        
        // If we're past September, target next year's peak season
        // If we're before May, target this year's peak season
        // If we're in peak season (May-Sep), target this year
        $target_year = ($current_month > 9) ? $current_year + 1 : $current_year;
        
        // Sync peak season in monthly chunks (May through September = 5 months)
        $chunks = array();
        $months = array(
            array('month' => 5, 'name' => 'May'),
            array('month' => 6, 'name' => 'June'),
            array('month' => 7, 'name' => 'July'),
            array('month' => 8, 'name' => 'August'),
            array('month' => 9, 'name' => 'September')
        );
        
        foreach ($months as $month_data) {
            $month = $month_data['month'];
            $dateFrom = new DateTime("$target_year-$month-01");
            $dateTo = clone $dateFrom;
            $dateTo->modify('last day of this month');
            
            $chunks[] = array(
                'dateFrom' => $dateFrom->format('Y-m-d') . 'T00:00:00',
                'dateTo' => $dateTo->format('Y-m-d') . 'T23:59:59',
                'label' => $month_data['name'] . ' ' . $target_year
            );
        }
        
        foreach ($all_companies as $company_id) {
            if (empty($company_id)) continue;
            
            $company_prices = 0;
            
            foreach ($chunks as $chunk) {
                try {
                    $prices = $this->api->get_prices($company_id, $chunk['dateFrom'], $chunk['dateTo']);
                    
                    // Validate response is an array
                    if (!is_array($prices)) {
                        $results['errors'][] = "Company $company_id: Unexpected price response format";
                        error_log('YOLO YS: Unexpected price response for company ' . $company_id);
                        continue;
                    }
                    
                    if (count($prices) > 0) {
                        foreach ($prices as $price) {
                            YOLO_YS_Database_Prices::store_price($price);
                            $company_prices++;
                        }
                    }
                    
                    $results['chunks_processed']++;
                    
                } catch (Exception $e) {
                    $results['errors'][] = "Company $company_id ({$chunk['dateFrom']} to {$chunk['dateTo']}): " . $e->getMessage();
                    error_log('YOLO YS: Failed to sync prices for company ' . $company_id . ': ' . $e->getMessage());
                }
            }
            
            if ($company_prices > 0) {
                $results['companies_processed']++;
                $results['prices_synced'] += $company_prices;
            }
        }
        
        // Delete old prices
        YOLO_YS_Database_Prices::delete_old_prices();
        
        if ($results['prices_synced'] > 0) {
            $results['success'] = true;
            $results['message'] = sprintf(
                'Successfully synced %d prices from %d companies for peak season %d (%d months processed)',
                $results['prices_synced'],
                $results['companies_processed'],
                $target_year,
                $results['chunks_processed']
            );
        } else {
            $results['success'] = true; // Still success even if no prices found
            $results['message'] = sprintf(
                'Price sync completed for peak season %d (May-September). No prices found.',
                $target_year
            );
        }
        
        // Update last price sync time
        update_option('yolo_ys_last_price_sync', current_time('mysql'));
        
        return $results;
    }
    
    /**
     * Get sync status
     */
    public function get_sync_status() {
        $stats = $this->db->get_sync_stats();
        $last_sync = get_option('yolo_ys_last_sync', null);
        $last_price_sync = get_option('yolo_ys_last_price_sync', null);
        
        return array(
            'total_yachts' => $stats['total_yachts'],
            'yolo_yachts' => $stats['yolo_yachts'],
            'partner_yachts' => $stats['total_yachts'] - $stats['yolo_yachts'],
            'last_sync' => $last_sync,
            'last_sync_human' => $last_sync ? human_time_diff(strtotime($last_sync), current_time('timestamp')) . ' ago' : 'Never',
            'last_price_sync' => $last_price_sync,
            'last_price_sync_human' => $last_price_sync ? human_time_diff(strtotime($last_price_sync), current_time('timestamp')) . ' ago' : 'Never'
        );
    }
}
