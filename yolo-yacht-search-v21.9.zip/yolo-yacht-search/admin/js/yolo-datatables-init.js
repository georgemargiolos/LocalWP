/**
 * YOLO DataTables Initialization
 * Enhances admin tables with sorting, searching, and pagination
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Common DataTables configuration
        var dataTableConfig = {
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            order: [[0, 'desc']], // Sort by first column (usually ID or date) descending
            responsive: true,
            dom: '<"top"lf>rt<"bottom"ip><"clear">',
            language: {
                search: "Filter:",
                lengthMenu: "Show _MENU_ entries",
                info: "Showing _START_ to _END_ of _TOTAL_ entries",
                infoEmpty: "No entries available",
                infoFiltered: "(filtered from _MAX_ total entries)",
                paginate: {
                    first: "First",
                    last: "Last",
                    next: "→",
                    previous: "←"
                }
            },
            drawCallback: function() {
                // Re-apply WordPress styling after DataTables renders
                $(this).find('tr').addClass('iedit');
            }
        };

        // Initialize Quote Requests DataTable
        if ($('#yolo-quotes-datatable').length) {
            $('#yolo-quotes-datatable').DataTable($.extend({}, dataTableConfig, {
                order: [[1, 'desc']], // Sort by Date column
                columnDefs: [
                    { orderable: false, targets: -1 } // Disable sorting on Actions column
                ]
            }));
        }

        // Initialize Contact Messages DataTable
        if ($('#yolo-messages-datatable').length) {
            $('#yolo-messages-datatable').DataTable($.extend({}, dataTableConfig, {
                order: [[1, 'desc']], // Sort by Date column
                columnDefs: [
                    { orderable: false, targets: -1 } // Disable sorting on Actions column
                ]
            }));
        }

        // Initialize Base Manager Yachts DataTable
        if ($('#yolo-bm-yachts-datatable').length) {
            $('#yolo-bm-yachts-datatable').DataTable($.extend({}, dataTableConfig, {
                pageLength: 10
            }));
        }

        // Initialize Base Manager Bookings DataTable
        if ($('#yolo-bm-bookings-datatable').length) {
            $('#yolo-bm-bookings-datatable').DataTable($.extend({}, dataTableConfig, {
                order: [[2, 'desc']], // Sort by Check-in Date
                pageLength: 10
            }));
        }
    });
})(jQuery);

