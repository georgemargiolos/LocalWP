<?php
/**
 * Charter Calendar View - FullCalendar Integration
 * Modern calendar view for bookings with drag support
 * 
 * @since 21.8
 */

if (!defined('ABSPATH')) {
    exit;
}

global $wpdb;
$table_bookings = $wpdb->prefix . 'yolo_bookings';

// Fetch all bookings for FullCalendar
$all_bookings = $wpdb->get_results("
    SELECT id, yacht_name, date_from, date_to, customer_name, customer_email, 
           payment_status, booking_status, total_price, currency
    FROM {$table_bookings}
    ORDER BY date_from ASC
");

// Convert bookings to FullCalendar events format
$calendar_events = array();
foreach ($all_bookings as $booking) {
    $color = '#6b7280'; // Default gray
    if ($booking->payment_status === 'fully_paid') {
        $color = '#10b981'; // Green
    } elseif ($booking->payment_status === 'deposit_paid') {
        $color = '#f59e0b'; // Orange
    } elseif ($booking->payment_status === 'pending') {
        $color = '#ef4444'; // Red
    }
    
    $calendar_events[] = array(
        'id' => $booking->id,
        'title' => $booking->yacht_name . ' - ' . $booking->customer_name,
        'start' => date('Y-m-d', strtotime($booking->date_from)),
        'end' => date('Y-m-d', strtotime($booking->date_to . ' +1 day')), // FullCalendar end is exclusive
        'backgroundColor' => $color,
        'borderColor' => $color,
        'extendedProps' => array(
            'yacht' => $booking->yacht_name,
            'customer' => $booking->customer_name,
            'email' => $booking->customer_email,
            'status' => $booking->payment_status,
            'price' => $booking->total_price,
            'currency' => $booking->currency
        )
    );
}

// Get statistics for Chart.js
$stats_by_month = $wpdb->get_results("
    SELECT 
        DATE_FORMAT(date_from, '%Y-%m') as month,
        COUNT(*) as bookings,
        SUM(total_price) as revenue
    FROM {$table_bookings}
    WHERE date_from >= DATE_SUB(NOW(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(date_from, '%Y-%m')
    ORDER BY month ASC
");

$chart_labels = array();
$chart_bookings = array();
$chart_revenue = array();

foreach ($stats_by_month as $stat) {
    $chart_labels[] = date('M Y', strtotime($stat->month . '-01'));
    $chart_bookings[] = intval($stat->bookings);
    $chart_revenue[] = floatval($stat->revenue);
}
?>

<div class="wrap yolo-charter-calendar-fc">
    <h1>Charter Calendar</h1>
    <p class="yolo-calendar-subtitle">Visual booking calendar powered by FullCalendar</p>
    
    <!-- Legend -->
    <div class="yolo-calendar-legend">
        <span class="legend-item"><span class="legend-dot" style="background: #10b981;"></span> Fully Paid</span>
        <span class="legend-item"><span class="legend-dot" style="background: #f59e0b;"></span> Deposit Paid</span>
        <span class="legend-item"><span class="legend-dot" style="background: #ef4444;"></span> Pending</span>
    </div>
    
    <!-- FullCalendar Container -->
    <div id="yolo-fullcalendar"></div>
    
    <!-- Analytics Section -->
    <div class="yolo-analytics-section">
        <h2>📊 Booking Analytics (Last 12 Months)</h2>
        <div class="yolo-charts-container">
            <div class="yolo-chart-box">
                <h3>Bookings per Month</h3>
                <canvas id="bookingsChart"></canvas>
            </div>
            <div class="yolo-chart-box">
                <h3>Revenue per Month (€)</h3>
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
    </div>
    
    <!-- Booking Detail Modal -->
    <div id="yolo-booking-modal" class="yolo-modal" style="display: none;">
        <div class="yolo-modal-content">
            <span class="yolo-modal-close">&times;</span>
            <div id="yolo-booking-modal-body">
                <!-- Filled by JavaScript -->
            </div>
        </div>
    </div>
</div>

<style>
.yolo-charter-calendar-fc {
    max-width: 1400px;
}

.yolo-calendar-subtitle {
    color: #666;
    font-size: 14px;
    margin-top: -10px;
    margin-bottom: 20px;
}

.yolo-calendar-legend {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
    padding: 12px 16px;
    background: #f8f9fa;
    border-radius: 8px;
}

.legend-item {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: #374151;
}

.legend-dot {
    width: 12px;
    height: 12px;
    border-radius: 50%;
}

#yolo-fullcalendar {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    margin-bottom: 40px;
}

/* FullCalendar Customization */
.fc {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

.fc .fc-toolbar-title {
    font-size: 1.5em;
    color: #1e3a8a;
}

.fc .fc-button-primary {
    background-color: #1e3a8a;
    border-color: #1e3a8a;
}

.fc .fc-button-primary:hover {
    background-color: #1e40af;
    border-color: #1e40af;
}

.fc .fc-button-primary:not(:disabled).fc-button-active {
    background-color: #172554;
    border-color: #172554;
}

.fc-event {
    cursor: pointer;
    font-size: 12px;
    padding: 2px 4px;
}

.fc-event:hover {
    opacity: 0.9;
}

/* Analytics Section */
.yolo-analytics-section {
    margin-top: 40px;
}

.yolo-analytics-section h2 {
    margin-bottom: 20px;
    color: #1e3a8a;
}

.yolo-charts-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 24px;
}

.yolo-chart-box {
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.yolo-chart-box h3 {
    margin: 0 0 16px 0;
    font-size: 16px;
    color: #374151;
}

.yolo-chart-box canvas {
    max-height: 300px;
}

/* Modal */
.yolo-modal {
    position: fixed;
    z-index: 100000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0,0,0,0.6);
}

.yolo-modal-content {
    position: relative;
    background-color: #fff;
    margin: 10% auto;
    padding: 30px;
    border-radius: 8px;
    width: 90%;
    max-width: 500px;
}

.yolo-modal-close {
    position: absolute;
    right: 20px;
    top: 15px;
    font-size: 28px;
    font-weight: bold;
    color: #aaa;
    cursor: pointer;
}

.yolo-modal-close:hover {
    color: #000;
}

.yolo-booking-detail {
    padding: 10px 0;
}

.yolo-booking-detail h3 {
    margin: 0 0 20px 0;
    color: #1e3a8a;
    font-size: 20px;
}

.yolo-detail-row {
    display: flex;
    padding: 8px 0;
    border-bottom: 1px solid #f3f4f6;
}

.yolo-detail-label {
    flex: 0 0 120px;
    font-weight: 600;
    color: #6b7280;
}

.yolo-detail-value {
    flex: 1;
    color: #1f2937;
}

.yolo-booking-actions {
    margin-top: 20px;
    display: flex;
    gap: 10px;
}

.yolo-btn {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
    font-weight: 500;
    text-decoration: none;
    display: inline-block;
    text-align: center;
}

.yolo-btn-primary {
    background: #1e3a8a;
    color: #fff;
}

.yolo-btn-primary:hover {
    background: #1e40af;
    color: #fff;
}

.yolo-btn-secondary {
    background: #f3f4f6;
    color: #374151;
}

.yolo-btn-secondary:hover {
    background: #e5e7eb;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // FullCalendar Initialization
    var calendarEl = document.getElementById('yolo-fullcalendar');
    var events = <?php echo json_encode($calendar_events); ?>;
    
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,listMonth'
        },
        events: events,
        eventClick: function(info) {
            showBookingModal(info.event);
        },
        eventDidMount: function(info) {
            // Add tooltip
            info.el.title = info.event.title;
        },
        height: 'auto',
        firstDay: 1, // Monday
        navLinks: true,
        dayMaxEvents: 3,
        moreLinkClick: 'popover'
    });
    
    calendar.render();
    
    // Show booking modal
    function showBookingModal(event) {
        var props = event.extendedProps;
        var modal = document.getElementById('yolo-booking-modal');
        var body = document.getElementById('yolo-booking-modal-body');
        
        var statusClass = 'status-pending';
        var statusLabel = 'Pending';
        if (props.status === 'fully_paid') {
            statusClass = 'status-paid';
            statusLabel = 'Fully Paid';
        } else if (props.status === 'deposit_paid') {
            statusClass = 'status-deposit';
            statusLabel = 'Deposit Paid';
        }
        
        var startDate = event.start.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        var endDate = new Date(event.end);
        endDate.setDate(endDate.getDate() - 1); // Adjust for FullCalendar's exclusive end
        endDate = endDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        
        body.innerHTML = `
            <div class="yolo-booking-detail">
                <h3>${props.yacht}</h3>
                <div class="yolo-detail-row">
                    <span class="yolo-detail-label">Customer:</span>
                    <span class="yolo-detail-value">${props.customer}</span>
                </div>
                <div class="yolo-detail-row">
                    <span class="yolo-detail-label">Email:</span>
                    <span class="yolo-detail-value">${props.email}</span>
                </div>
                <div class="yolo-detail-row">
                    <span class="yolo-detail-label">Dates:</span>
                    <span class="yolo-detail-value">${startDate} → ${endDate}</span>
                </div>
                <div class="yolo-detail-row">
                    <span class="yolo-detail-label">Total Price:</span>
                    <span class="yolo-detail-value">€${parseFloat(props.price).toLocaleString()}</span>
                </div>
                <div class="yolo-detail-row">
                    <span class="yolo-detail-label">Status:</span>
                    <span class="yolo-detail-value"><span class="yolo-booking-status ${statusClass}">${statusLabel}</span></span>
                </div>
                <div class="yolo-booking-actions">
                    <a href="?page=yolo-ys-bookings&view=table&action=view&booking_id=${event.id}" class="yolo-btn yolo-btn-primary">View Details</a>
                    <button class="yolo-btn yolo-btn-secondary" onclick="document.getElementById('yolo-booking-modal').style.display='none'">Close</button>
                </div>
            </div>
        `;
        
        modal.style.display = 'block';
    }
    
    // Close modal
    document.querySelector('.yolo-modal-close').addEventListener('click', function() {
        document.getElementById('yolo-booking-modal').style.display = 'none';
    });
    
    window.addEventListener('click', function(e) {
        var modal = document.getElementById('yolo-booking-modal');
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    // Chart.js Initialization
    var chartLabels = <?php echo json_encode($chart_labels); ?>;
    var chartBookings = <?php echo json_encode($chart_bookings); ?>;
    var chartRevenue = <?php echo json_encode($chart_revenue); ?>;
    
    // Bookings Chart
    if (document.getElementById('bookingsChart') && chartLabels.length > 0) {
        new Chart(document.getElementById('bookingsChart'), {
            type: 'bar',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: 'Bookings',
                    data: chartBookings,
                    backgroundColor: 'rgba(30, 58, 138, 0.8)',
                    borderColor: 'rgba(30, 58, 138, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    // Revenue Chart
    if (document.getElementById('revenueChart') && chartLabels.length > 0) {
        new Chart(document.getElementById('revenueChart'), {
            type: 'line',
            data: {
                labels: chartLabels,
                datasets: [{
                    label: 'Revenue (€)',
                    data: chartRevenue,
                    backgroundColor: 'rgba(16, 185, 129, 0.2)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '€' + value.toLocaleString();
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
});
</script>
