/**
 * YOLO Toast - Wrapper for Toastify.js
 * Provides easy-to-use toast notifications
 */
window.YoloToast = {
    // Success toast (green)
    success: function(message, duration) {
        if (typeof Toastify === 'undefined') {
            console.log('Success:', message);
            return;
        }
        Toastify({
            text: message,
            duration: duration || 3000,
            gravity: "top",
            position: "right",
            stopOnFocus: true,
            style: {
                background: "linear-gradient(to right, #059669, #10b981)",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(5, 150, 105, 0.3)"
            }
        }).showToast();
    },
    
    // Error toast (red)
    error: function(message, duration) {
        if (typeof Toastify === 'undefined') {
            console.error('Error:', message);
            return;
        }
        Toastify({
            text: message,
            duration: duration || 4000,
            gravity: "top",
            position: "right",
            stopOnFocus: true,
            style: {
                background: "linear-gradient(to right, #dc2626, #ef4444)",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(220, 38, 38, 0.3)"
            }
        }).showToast();
    },
    
    // Warning toast (orange)
    warning: function(message, duration) {
        if (typeof Toastify === 'undefined') {
            console.warn('Warning:', message);
            return;
        }
        Toastify({
            text: message,
            duration: duration || 3500,
            gravity: "top",
            position: "right",
            stopOnFocus: true,
            style: {
                background: "linear-gradient(to right, #d97706, #f59e0b)",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(217, 119, 6, 0.3)"
            }
        }).showToast();
    },
    
    // Info toast (blue)
    info: function(message, duration) {
        if (typeof Toastify === 'undefined') {
            console.info('Info:', message);
            return;
        }
        Toastify({
            text: message,
            duration: duration || 3000,
            gravity: "top",
            position: "right",
            stopOnFocus: true,
            style: {
                background: "linear-gradient(to right, #1e3a8a, #3b82f6)",
                borderRadius: "8px",
                boxShadow: "0 4px 12px rgba(30, 58, 138, 0.3)"
            }
        }).showToast();
    }
};

