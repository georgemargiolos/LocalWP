<?php
/**
 * Guest Dashboard Template
 * 
 * Bootstrap 5 Implementation:
 * - Uses Bootstrap cards, grid, and utility classes
 * - Responsive design with proper breakpoints
 * - Accessible form elements and navigation
 * 
 * @package YOLO_Yacht_Search
 * @since 2.5.6
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$user = wp_get_current_user();
?>

<div class="yolo-guest-dashboard container py-5">
    <!-- Header Section -->
    <header class="text-center mb-5">
        <h1 class="display-5 fw-bold text-dark mb-2">Welcome, <?php echo esc_html($user->first_name); ?>!</h1>
        <p class="lead text-muted mb-4">Manage your yacht bookings and upload your sailing license</p>
        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="btn btn-outline-danger">
            <i class="bi bi-box-arrow-right me-2"></i>Logout
        </a>
    </header>
    
    <?php if (empty($bookings)): ?>
        <!-- No Bookings State -->
        <div class="alert alert-info text-center py-5" role="alert">
            <h3 class="alert-heading h4 fw-bold">No Bookings Found</h3>
            <p class="mb-3">You don't have any bookings yet.</p>
            <a href="<?php echo esc_url(home_url('/search-yachts')); ?>" class="btn btn-primary">
                <i class="bi bi-search me-2"></i>Browse Our Yachts
            </a>
        </div>
    <?php else: ?>
        <!-- Bookings List -->
        <div class="row g-4">
            <?php foreach ($bookings as $booking): ?>
                <div class="col-12">
                    <article class="card shadow-sm">
                        <!-- Card Header -->
                        <div class="card-header bg-white py-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
                            <h2 class="card-title h5 fw-bold text-dark mb-0">
                                <?php echo esc_html($booking->yacht_name); ?>
                            </h2>
                            <span class="badge fs-6 <?php 
                                echo $booking->booking_status === 'confirmed' ? 'bg-success' : 
                                    ($booking->booking_status === 'pending' ? 'bg-warning text-dark' : 'bg-secondary'); 
                            ?>">
                                <?php echo esc_html(ucfirst($booking->booking_status)); ?>
                            </span>
                        </div>
                        
                        <div class="card-body">
                            <div class="row g-4">
                                <!-- Booking Details Column -->
                                <div class="col-lg-6">
                                    <h3 class="h6 fw-semibold text-uppercase text-muted mb-3">Booking Details</h3>
                                    
                                    <div class="d-flex flex-column gap-2">
                                        <div class="d-flex justify-content-between align-items-center p-2 bg-light rounded">
                                            <span class="text-muted">📅 Check-in:</span>
                                            <span class="fw-semibold"><?php echo date('F j, Y', strtotime($booking->date_from)); ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center p-2 bg-light rounded">
                                            <span class="text-muted">📅 Check-out:</span>
                                            <span class="fw-semibold"><?php echo date('F j, Y', strtotime($booking->date_to)); ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center p-2 bg-light rounded">
                                            <span class="text-muted">💰 Total Price:</span>
                                            <span class="fw-semibold"><?php echo esc_html($booking->currency); ?> <?php echo number_format($booking->total_price, 2); ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center p-2 bg-success bg-opacity-10 rounded">
                                            <span class="text-success">✅ Deposit Paid:</span>
                                            <span class="fw-semibold text-success"><?php echo esc_html($booking->currency); ?> <?php echo number_format($booking->deposit_paid, 2); ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center p-2 bg-warning bg-opacity-10 rounded">
                                            <span class="text-warning">⏳ Remaining:</span>
                                            <span class="fw-semibold text-warning"><?php echo esc_html($booking->currency); ?> <?php echo number_format($booking->remaining_balance, 2); ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center p-2 bg-light rounded">
                                            <span class="text-muted">🔖 Confirmation #:</span>
                                            <span class="fw-semibold"><?php echo esc_html($booking->id); ?></span>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- License Upload Column -->
                                <div class="col-lg-6">
                                    <h3 class="h6 fw-semibold text-uppercase text-muted mb-3">📜 Sailing License</h3>
                                    <p class="text-muted small mb-3">Please upload both sides of your sailing license for verification.</p>
                                    
                                    <?php
                                    $booking_licenses = isset($licenses[$booking->id]) ? $licenses[$booking->id] : array();
                                    $has_front = false;
                                    $has_back = false;
                                    $front_url = '';
                                    $back_url = '';
                                    
                                    foreach ($booking_licenses as $license) {
                                        if ($license->file_type === 'front') {
                                            $has_front = true;
                                            $front_url = $license->file_url;
                                        }
                                        if ($license->file_type === 'back') {
                                            $has_back = true;
                                            $back_url = $license->file_url;
                                        }
                                    }
                                    ?>
                                    
                                    <div class="row g-3">
                                        <!-- Front License -->
                                        <div class="col-md-6">
                                            <div class="card h-100">
                                                <div class="card-body">
                                                    <h4 class="h6 fw-semibold mb-3">Front Side</h4>
                                                    
                                                    <?php if ($has_front): ?>
                                                        <div class="mb-3 position-relative">
                                                            <img src="<?php echo esc_url($front_url); ?>" alt="License Front" class="img-fluid rounded border" style="max-height: 150px; object-fit: cover;">
                                                            <span class="badge bg-success position-absolute bottom-0 end-0 m-2">✓ Uploaded</span>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <form class="yolo-license-form" data-booking-id="<?php echo esc_attr($booking->id); ?>" data-file-type="front">
                                                        <div class="mb-2">
                                                            <input type="file" name="license_file" accept="image/*" required class="form-control form-control-sm">
                                                        </div>
                                                        <button type="submit" class="btn btn-primary btn-sm w-100">
                                                            <?php echo $has_front ? 'Replace Front' : 'Upload Front'; ?>
                                                        </button>
                                                        <div class="yolo-upload-message mt-2 small"></div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <!-- Back License -->
                                        <div class="col-md-6">
                                            <div class="card h-100">
                                                <div class="card-body">
                                                    <h4 class="h6 fw-semibold mb-3">Back Side</h4>
                                                    
                                                    <?php if ($has_back): ?>
                                                        <div class="mb-3 position-relative">
                                                            <img src="<?php echo esc_url($back_url); ?>" alt="License Back" class="img-fluid rounded border" style="max-height: 150px; object-fit: cover;">
                                                            <span class="badge bg-success position-absolute bottom-0 end-0 m-2">✓ Uploaded</span>
                                                        </div>
                                                    <?php endif; ?>
                                                    
                                                    <form class="yolo-license-form" data-booking-id="<?php echo esc_attr($booking->id); ?>" data-file-type="back">
                                                        <div class="mb-2">
                                                            <input type="file" name="license_file" accept="image/*" required class="form-control form-control-sm">
                                                        </div>
                                                        <button type="submit" class="btn btn-primary btn-sm w-100">
                                                            <?php echo $has_back ? 'Replace Back' : 'Upload Back'; ?>
                                                        </button>
                                                        <div class="yolo-upload-message mt-2 small"></div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<script>
jQuery(document).ready(function($) {
    $('.yolo-license-form').on('submit', function(e) {
        e.preventDefault();
        
        var form = $(this);
        var bookingId = form.data('booking-id');
        var fileType = form.data('file-type');
        var fileInput = form.find('input[type="file"]')[0];
        var messageDiv = form.find('.yolo-upload-message');
        var submitBtn = form.find('button[type="submit"]');
        
        if (!fileInput.files || !fileInput.files[0]) {
            messageDiv.html('<span class="text-danger">Please select a file</span>');
            return;
        }
        
        var formData = new FormData();
        formData.append('action', 'yolo_upload_license');
        formData.append('nonce', '<?php echo wp_create_nonce('yolo_upload_license'); ?>');
        formData.append('booking_id', bookingId);
        formData.append('file_type', fileType);
        formData.append('license_file', fileInput.files[0]);
        
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm me-2" role="status"></span>Uploading...');
        messageDiv.html('');
        
        $.ajax({
            url: '<?php echo admin_url('admin-ajax.php'); ?>',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    messageDiv.html('<span class="text-success">✓ ' + response.data.message + '</span>');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                } else {
                    messageDiv.html('<span class="text-danger">✗ ' + response.data.message + '</span>');
                    submitBtn.prop('disabled', false).text(fileType === 'front' ? 'Upload Front' : 'Upload Back');
                }
            },
            error: function() {
                messageDiv.html('<span class="text-danger">✗ Upload failed. Please try again.</span>');
                submitBtn.prop('disabled', false).text(fileType === 'front' ? 'Upload Front' : 'Upload Back');
            }
        });
    });
});
</script>
