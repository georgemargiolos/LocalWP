<?php
/**
 * Booking Confirmation Template
 * Shortcode: [yolo_booking_confirmation]
 * 
 * This page is shown after successful Stripe payment.
 * It creates the booking in the database if it doesn't exist yet.
 */

// Get session ID from URL
$session_id = isset($_GET['session_id']) ? sanitize_text_field($_GET['session_id']) : '';

if (empty($session_id)) {
    echo '<div class="yolo-booking-error">';
    echo '<h2>Invalid Booking Reference</h2>';
    echo '<p>We could not find your booking. Please check your email for confirmation details.</p>';
    echo '</div>';
    return;
}

// Check if booking already exists
global $wpdb;
$table_bookings = $wpdb->prefix . 'yolo_bookings';
$booking = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$table_bookings} WHERE stripe_session_id = %s",
    $session_id
));

// If booking doesn't exist, create it from Stripe session
if (!$booking) {
    try {
        // Initialize Stripe
        $secret_key = get_option('yolo_ys_stripe_secret_key', '');
        if (!empty($secret_key)) {
            \Stripe\Stripe::setApiKey($secret_key);
            
            // Retrieve session from Stripe
            $session = \Stripe\Checkout\Session::retrieve($session_id);
            
            // Check if payment was successful
            if ($session->payment_status === 'paid') {
                // Extract booking details from metadata
                $yacht_id = $session->metadata->yacht_id;
                $yacht_name = $session->metadata->yacht_name;
                $date_from = $session->metadata->date_from;
                $date_to = $session->metadata->date_to;
                $total_price = $session->metadata->total_price;
                $deposit_amount = $session->metadata->deposit_amount;
                $remaining_balance = $session->metadata->remaining_balance;
                $currency = isset($session->metadata->currency) ? $session->metadata->currency : 'EUR';
                
                // Get customer details from metadata (preferred) or customer_details (fallback)
                $customer_first_name = isset($session->metadata->customer_first_name) ? $session->metadata->customer_first_name : '';
                $customer_last_name = isset($session->metadata->customer_last_name) ? $session->metadata->customer_last_name : '';
                $customer_name = isset($session->metadata->customer_name) ? $session->metadata->customer_name : '';
                $customer_email = isset($session->metadata->customer_email) ? $session->metadata->customer_email : '';
                $customer_phone = isset($session->metadata->customer_phone) ? $session->metadata->customer_phone : '';
                
                // Fallback to Stripe customer_details if metadata is empty
                if (empty($customer_email) && isset($session->customer_details->email)) {
                    $customer_email = $session->customer_details->email;
                }
                if (empty($customer_name) && isset($session->customer_details->name)) {
                    $customer_name = $session->customer_details->name;
                }
                
                // Create booking in database
                $wpdb->insert($table_bookings, array(
                    'yacht_id' => $yacht_id,
                    'yacht_name' => $yacht_name,
                    'date_from' => $date_from,
                    'date_to' => $date_to,
                    'total_price' => $total_price,
                    'deposit_paid' => $deposit_amount,
                    'remaining_balance' => $remaining_balance,
                    'currency' => $currency,
                    'customer_name' => $customer_name,
                    'customer_email' => $customer_email,
                    'customer_phone' => $customer_phone,
                    'stripe_session_id' => $session_id,
                    'stripe_payment_intent' => isset($session->payment_intent) ? $session->payment_intent : '',
                    'payment_status' => 'deposit_paid',
                    'booking_status' => 'confirmed',
                    'created_at' => current_time('mysql'),
                ));
                
                $booking_id = $wpdb->insert_id;
                
                // Create reservation in Booking Manager
                $api = new YOLO_YS_Booking_Manager_API();
                
                // Prepare reservation data
                $reservation_data = array(
                    'yachtId' => (int)$yacht_id,
                    'dateFrom' => date('Y-m-d\TH:i:s', strtotime($date_from)),
                    'dateTo' => date('Y-m-d\TH:i:s', strtotime($date_to)),
                    'client' => array(
                        'name' => $customer_name,
                        'email' => $customer_email,
                    ),
                    'status' => 1, // 1 = Confirmed
                    'sendNotification' => true,
                    'note' => 'Online booking via YOLO Charters. Stripe Payment: ' . (isset($session->payment_intent) ? $session->payment_intent : ''),
                );
                
                $result = $api->create_reservation($reservation_data);
                
                if ($result['success']) {
                    $bm_reservation_id = isset($result['data']['id']) ? $result['data']['id'] : null;
                    
                    // Update booking with Booking Manager reservation ID
                    $wpdb->update(
                        $table_bookings,
                        array('bm_reservation_id' => $bm_reservation_id),
                        array('id' => $booking_id)
                    );
                    
                    // Record payment in Booking Manager
                    if ($bm_reservation_id) {
                        $payment_data = array(
                            'amount' => floatval($deposit_amount),
                            'currency' => $currency,
                            'paymentDate' => current_time('Y-m-d\TH:i:s'),
                            'paymentMethod' => 'Credit Card (Stripe)',
                            'note' => 'Deposit payment. Stripe Payment Intent: ' . (isset($session->payment_intent) ? $session->payment_intent : ''),
                        );
                        
                        $payment_result = $api->create_payment($bm_reservation_id, $payment_data);
                        
                        if (!$payment_result['success']) {
                            error_log('YOLO YS: Failed to record payment in Booking Manager: ' . print_r($payment_result, true));
                        }
                    }
                    
                    error_log('YOLO YS: Booking Manager reservation created - ID: ' . $bm_reservation_id);
                } else {
                    error_log('YOLO YS: Failed to create Booking Manager reservation: ' . print_r($result, true));
                    
                    // Send alert email to admin
                    $admin_email = get_option('admin_email');
                    $admin_subject = 'ACTION REQUIRED: Booking #' . $booking_id . ' - Manual Confirmation Needed';
                    $admin_message = "A customer has paid but the automatic reservation in Booking Manager failed.\n\n";
                    $admin_message .= "Please manually create the reservation in Booking Manager.\n\n";
                    $admin_message .= "Booking ID: #" . $booking_id . "\n";
                    $admin_message .= "Yacht: " . $yacht_name . "\n";
                    $admin_message .= "Customer: " . $customer_name . "\n";
                    $admin_message .= "Email: " . $customer_email . "\n";
                    $admin_message .= "Dates: " . date('M d, Y', strtotime($date_from)) . " - " . date('M d, Y', strtotime($date_to)) . "\n";
                    $admin_message .= "Deposit: " . YOLO_YS_Price_Formatter::format_price($deposit_amount, $currency) . "\n\n";
                    $admin_message .= "Error: " . (isset($result['error']) ? $result['error'] : 'Unknown error') . "\n";
                    
                    wp_mail($admin_email, $admin_subject, $admin_message, array('Content-Type: text/plain; charset=UTF-8'));
                }
                
                // FIRST: Retrieve the newly created booking (MUST be before emails!)
                $booking = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$table_bookings} WHERE id = %d",
                    $booking_id
                ));
                
                error_log('YOLO YS: Booking created on return from Stripe - ID: ' . $booking_id);
                
                // CREATE GUEST USER (this is critical - webhook may not work!)
                if ($booking && !empty($customer_email)) {
                    error_log('YOLO YS: Creating guest user from confirmation page...');
                    
                    if (class_exists('YOLO_YS_Guest_Users')) {
                        $guest_manager = new YOLO_YS_Guest_Users();
                        
                        // Split name into first/last
                        $name_parts = explode(' ', trim($customer_name), 2);
                        $first_name = isset($name_parts[0]) ? $name_parts[0] : $customer_name;
                        $last_name = isset($name_parts[1]) ? $name_parts[1] : '';
                        
                        $guest_result = $guest_manager->create_guest_user(
                            $booking_id,
                            $customer_email,
                            $first_name,
                            $last_name,
                            $booking_id
                        );
                        
                        error_log('YOLO YS: Guest user creation result: ' . print_r($guest_result, true));
                        
                        // Send guest credentials email if user was created
                        if ($guest_result['success'] && !empty($guest_result['password'])) {
                            $login_url = wp_login_url(home_url('/guest-dashboard'));
                            $credentials_message = sprintf(
                                "Your guest account has been created!\n\n" .
                                "Username: %s\n" .
                                "Password: %s\n\n" .
                                "Login here: %s",
                                $guest_result['username'],
                                $guest_result['password'],
                                $login_url
                            );
                            wp_mail($customer_email, 'Your Guest Account - YOLO Charters', $credentials_message);
                            error_log('YOLO YS: Guest credentials email sent to ' . $customer_email);
                        }
                    } else {
                        error_log('YOLO YS ERROR: YOLO_YS_Guest_Users class not found!');
                    }
                }
                
                // NOW send confirmation emails (booking is no longer null)
                if ($booking) {
                    try {
                        YOLO_YS_Email::send_booking_confirmation($booking);
                        YOLO_YS_Email::send_admin_notification($booking);
                    } catch (Exception $email_error) {
                        error_log('YOLO YS: Email sending error - ' . $email_error->getMessage());
                    }
                }
            }
        }
    } catch (Exception $e) {
        error_log('YOLO YS: Failed to create booking from Stripe session - ' . $e->getMessage());
    }
}

// If still no booking, show error
if (!$booking) {
    echo '<div class="container py-5">';
    echo '<div class="alert alert-info text-center py-5" role="alert">';
    echo '<h2 class="alert-heading">Processing Payment</h2>';
    echo '<p class="mb-0">We are processing your payment. Please check your email for confirmation or contact us if you have any questions.</p>';
    echo '</div>';
    echo '</div>';
    return;
}

// Get deposit percentage
$deposit_percentage = get_option('yolo_ys_deposit_percentage', 50);
?>

<div class="yolo-booking-confirmation container py-5">
    <!-- Success Header -->
    <header class="text-center mb-5">
        <div class="success-icon mb-4">
            <svg width="80" height="80" viewBox="0 0 80 80" fill="none" class="d-block mx-auto">
                <circle cx="40" cy="40" r="38" stroke="#10b981" stroke-width="4"/>
                <path d="M25 40L35 50L55 30" stroke="#10b981" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
        </div>
        <h1 class="display-5 fw-bold text-success">Booking Confirmed!</h1>
        <p class="lead text-muted">Thank you for your booking. Your yacht charter is confirmed.</p>
    </header>
    
    <div class="row g-4">
        <!-- Booking Details Card -->
        <div class="col-lg-6">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-primary text-white">
                    <h2 class="h5 mb-0">Booking Details</h2>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Booking Reference:</span>
                            <strong class="text-primary">#<?php echo esc_html($booking->id); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Yacht:</span>
                            <strong><?php echo esc_html($booking->yacht_name); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Charter Period:</span>
                            <strong><?php echo date('M j', strtotime($booking->date_from)); ?> - <?php echo date('M j, Y', strtotime($booking->date_to)); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Duration:</span>
                            <strong><?php 
                                $days = (strtotime($booking->date_to) - strtotime($booking->date_from)) / 86400;
                                echo intval($days) . ' days';
                            ?></strong>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Payment Summary Card -->
        <div class="col-lg-6">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-success text-white">
                    <h2 class="h5 mb-0">Payment Summary</h2>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Total Charter Price:</span>
                            <strong><?php echo YOLO_YS_Price_Formatter::format_price($booking->total_price, $booking->currency); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between bg-success bg-opacity-10">
                            <span class="text-success">Deposit Paid (<?php echo $deposit_percentage; ?>%):</span>
                            <strong class="text-success"><?php echo YOLO_YS_Price_Formatter::format_price($booking->deposit_paid, $booking->currency); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between bg-warning bg-opacity-10">
                            <span class="text-warning">Remaining Balance:</span>
                            <strong class="text-warning"><?php echo YOLO_YS_Price_Formatter::format_price($booking->remaining_balance, $booking->currency); ?></strong>
                        </li>
                    </ul>
                    
                    <div class="alert alert-warning mt-3 mb-0" role="alert">
                        <strong>Important:</strong> The remaining balance of <?php echo YOLO_YS_Price_Formatter::format_price($booking->remaining_balance, $booking->currency); ?> is due before your charter date. We will contact you with payment instructions.
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Contact Information Card -->
        <div class="col-lg-6">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-secondary text-white">
                    <h2 class="h5 mb-0">Contact Information</h2>
                </div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Name:</span>
                            <strong><?php echo esc_html($booking->customer_name); ?></strong>
                        </li>
                        <li class="list-group-item d-flex justify-content-between">
                            <span class="text-muted">Email:</span>
                            <strong><?php echo esc_html($booking->customer_email); ?></strong>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- What's Next Card -->
        <div class="col-lg-6">
            <div class="card h-100 shadow-sm">
                <div class="card-header bg-info text-white">
                    <h2 class="h5 mb-0">What's Next?</h2>
                </div>
                <div class="card-body">
                    <ol class="list-group list-group-numbered list-group-flush">
                        <li class="list-group-item">
                            <strong>Confirmation Email:</strong> Check your inbox at <?php echo esc_html($booking->customer_email); ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Remaining Payment:</strong> We'll contact you 30 days before your charter
                        </li>
                        <li class="list-group-item">
                            <strong>Charter Details:</strong> You'll receive yacht info and check-in procedures
                        </li>
                        <li class="list-group-item">
                            <strong>Questions?</strong> <a href="mailto:info@yolocharters.com">info@yolocharters.com</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Action Buttons -->
    <div class="text-center mt-5">
        <a href="<?php echo home_url(); ?>" class="btn btn-primary btn-lg me-2">
            <i class="bi bi-house-fill me-2"></i>Return to Home
        </a>
        <a href="<?php echo home_url('/our-yachts'); ?>" class="btn btn-outline-primary btn-lg">
            <i class="bi bi-search me-2"></i>Browse More Yachts
        </a>
    </div>
</div>
