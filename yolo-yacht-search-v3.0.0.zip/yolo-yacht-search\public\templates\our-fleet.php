<?php
/**
 * Our Fleet Template
 * 
 * Bootstrap 5 Best Practices:
 * - Uses Bootstrap container and grid system
 * - Responsive columns (3 on desktop, 2 on tablet, 1 on mobile)
 * - Bootstrap utility classes for spacing and typography
 * - Accessible semantic HTML
 * 
 * @package YOLO_Yacht_Search
 * @since 2.5.6
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get database instance
$db = new YOLO_YS_Database();

// Get YOLO company ID
$yolo_company_id = get_option('yolo_ys_my_company_id', 7850);

// Get all yachts
$yolo_yachts = $db->get_all_yachts($yolo_company_id);
$partner_yachts = $db->get_all_yachts(); // Get all
$partner_yachts = array_filter($partner_yachts, function($yacht) use ($yolo_company_id) {
    return $yacht->company_id != $yolo_company_id;
});

?>

<div class="yolo-ys-our-fleet container py-5">
    
    <?php if (empty($yolo_yachts) && empty($partner_yachts)): ?>
        <div class="alert alert-info text-center py-5" role="alert">
            <h4 class="alert-heading">No Yachts Available</h4>
            <p class="mb-0">Please sync yacht data from the admin panel.</p>
        </div>
    <?php else: ?>
        
        <!-- YOLO Fleet Section -->
        <?php if (!empty($yolo_yachts)): ?>
            <section class="yolo-ys-fleet-section mb-5">
                <header class="text-center mb-4">
                    <h2 class="display-6 fw-bold text-primary">
                        <span class="badge bg-danger rounded-pill me-2 align-middle" style="font-size: 0.5em;">YOLO Charters</span>
                        Our Fleet
                    </h2>
                </header>
                
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                    <?php foreach ($yolo_yachts as $yacht): ?>
                        <div class="col">
                            <?php include YOLO_YS_PLUGIN_DIR . 'public/templates/partials/yacht-card.php'; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
        
        <!-- Partner Fleet Section -->
        <?php if (!empty($partner_yachts)): ?>
            <section class="yolo-ys-fleet-section yolo-ys-partner-fleet">
                <header class="text-center mb-4">
                    <h2 class="display-6 fw-bold text-secondary">Partner Companies</h2>
                </header>
                
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                    <?php foreach ($partner_yachts as $yacht): ?>
                        <div class="col">
                            <?php include YOLO_YS_PLUGIN_DIR . 'public/templates/partials/yacht-card.php'; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
        
    <?php endif; ?>
    
</div>
