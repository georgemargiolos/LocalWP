<?php
/**
 * Yacht Card Partial Template
 *
 * Bootstrap 5 Card Component Implementation
 * - Uses Bootstrap card classes for consistent styling
 * - Responsive with hover effects
 * - Accessible markup
 *
 * @var object $yacht Yacht object from database
 * @package YOLO_Yacht_Search
 * @since 2.5.6
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$is_yolo = ($yacht->company_id == get_option('yolo_ys_my_company_id', 7850));
$details_page_id = get_option('yolo_ys_yacht_details_page', '');
$details_url = $details_page_id ? add_query_arg('yacht_id', $yacht->id, get_permalink($details_page_id)) : '#';

// Get primary image
$primary_image = '';
if (!empty($yacht->images)) {
    foreach ($yacht->images as $img) {
        if ($img->is_primary) {
            $primary_image = $img->image_url;
            break;
        }
    }
    if (empty($primary_image)) {
        $primary_image = $yacht->images[0]->image_url;
    }
}

// Format refit display
$refit_display = '';
if ($yacht->refit_year) {
    $refit_display = 'Refit: ' . $yacht->refit_year;
}

// Convert meters to feet
$length_ft = $yacht->length ? round($yacht->length * 3.28084) : 0;

// Get minimum price
$min_price = YOLO_YS_Database_Prices::get_min_price($yacht->id);
?>

<article class="card h-100 shadow-sm yacht-card <?php echo $is_yolo ? 'yacht-card-yolo' : ''; ?>">
    <!-- Yacht Image -->
    <div class="yacht-card-image position-relative overflow-hidden" style="height: 240px;">
        <?php if ($primary_image): ?>
            <img src="<?php echo esc_url($primary_image); ?>"
                 alt="<?php echo esc_attr($yacht->name . ' - ' . $yacht->model); ?>"
                 class="card-img-top w-100 h-100"
                 style="object-fit: cover; transition: transform 0.3s ease;"
                 loading="lazy">
        <?php else: ?>
            <div class="d-flex align-items-center justify-content-center h-100 bg-light text-muted" style="font-size: 4rem;">
                ⛵
            </div>
        <?php endif; ?>

        <?php if ($is_yolo): ?>
            <span class="badge bg-danger position-absolute top-0 end-0 m-2">YOLO</span>
        <?php endif; ?>
    </div>

    <div class="card-body d-flex flex-column">
        <!-- Location -->
        <?php if ($yacht->home_base): ?>
            <p class="text-muted small mb-2">
                <i class="bi bi-geo-alt-fill"></i> <?php echo esc_html($yacht->home_base); ?>
            </p>
        <?php endif; ?>

        <!-- Name and Model -->
        <header class="mb-3">
            <h3 class="card-title h5 fw-bold text-dark mb-1"><?php echo esc_html($yacht->name); ?></h3>
            <h4 class="card-subtitle h6 text-primary fw-semibold mb-0"><?php echo esc_html($yacht->model); ?></h4>
        </header>

        <!-- Specs Grid -->
        <div class="row text-center g-2 mb-3">
            <div class="col-4">
                <div class="fw-bold text-dark"><?php echo esc_html($yacht->cabins); ?></div>
                <small class="text-muted">Cabins</small>
            </div>

            <div class="col-4">
                <div class="fw-bold text-dark">
                    <?php echo esc_html($yacht->year_of_build); ?>
                </div>
                <?php if ($refit_display): ?>
                    <small class="text-muted d-block" style="font-size: 10px;"><?php echo esc_html($refit_display); ?></small>
                <?php else: ?>
                    <small class="text-muted">Built</small>
                <?php endif; ?>
            </div>

            <div class="col-4">
                <div class="fw-bold text-dark"><?php echo esc_html($length_ft); ?> ft</div>
                <small class="text-muted">Length</small>
            </div>
        </div>

        <!-- Price (pushed to bottom with mt-auto) -->
        <div class="mt-auto">
            <?php if ($min_price && isset($min_price->min_price)): ?>
            <div class="bg-success bg-opacity-10 text-success text-center p-2 rounded mb-3">
                <span class="small">From</span>
                <strong class="d-block fs-5"><?php echo number_format($min_price->min_price, 0, ',', '.'); ?> <?php echo esc_html($min_price->currency); ?></strong>
                <span class="small">per week</span>
            </div>
            <?php endif; ?>

            <!-- Details Button -->
            <a href="<?php echo esc_url($details_url); ?>"
               class="btn btn-danger w-100 fw-bold"
               aria-label="View details for <?php echo esc_attr($yacht->name); ?>">
                DETAILS
            </a>
        </div>
    </div>
</article>

<style>
/* Yacht Card Hover Effects */
.yacht-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.yacht-card:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15) !important;
}

.yacht-card:hover .yacht-card-image img {
    transform: scale(1.05);
}

.yacht-card .btn-danger {
    background-color: #b91c1c;
    border-color: #b91c1c;
}

.yacht-card .btn-danger:hover {
    background-color: #991b1b;
    border-color: #991b1b;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(185, 28, 28, 0.3);
}

/* YOLO yacht highlight */
.yacht-card-yolo {
    border-top: 3px solid #dc2626;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .yacht-card-image {
        height: 200px !important;
    }
}
</style>
