<style>
/**
 * YOLO Yacht Details v3 Styles
 * 
 * Bootstrap 5 Best Practices:
 * - Uses Bootstrap utility classes in HTML where possible
 * - Custom CSS only for YOLO branding and unique components
 * - Follows mobile-first responsive design
 * - Maintains accessibility standards
 */

/* ==========================================================================
   YOLO Brand Colors (CSS Custom Properties)
   ========================================================================== */
:root {
    --yolo-primary: #1e3a8a;
    --yolo-primary-dark: #1e40af;
    --yolo-secondary: #dc2626;
    --yolo-secondary-dark: #b91c1c;
    --yolo-success: #059669;
    --yolo-warning: #f59e0b;
    --yolo-text: #1f2937;
    --yolo-text-muted: #6b7280;
    --yolo-bg-light: #f9fafb;
    --yolo-border: #e5e7eb;
}

/* ==========================================================================
   Main Container
   ========================================================================== */
.yolo-yacht-details-v3 {
    max-width: 1500px;
}

/* ==========================================================================
   Yacht Header
   ========================================================================== */
.yacht-name {
    letter-spacing: 2px;
}

.yacht-model {
    color: var(--yolo-primary);
}

/* ==========================================================================
   Image Carousel (Custom Component)
   ========================================================================== */
.carousel-slide {
    opacity: 0;
    transition: opacity 0.5s ease;
}

.carousel-slide.active {
    opacity: 1;
}

.carousel-prev,
.carousel-next {
    font-size: 28px;
    width: 50px;
    height: 50px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    z-index: 10;
}

.carousel-prev:hover,
.carousel-next:hover {
    opacity: 1 !important;
}

.carousel-dots .dot {
    transition: background-color 0.3s ease;
}

.carousel-dots .dot.active,
.carousel-dots .dot:hover {
    background-color: white !important;
}

/* ==========================================================================
   Booking Section (Sticky Sidebar)
   ========================================================================== */
.yacht-booking-section {
    border-color: var(--yolo-border) !important;
}

.yacht-booking-section h3 {
    color: var(--yolo-text);
}

/* ==========================================================================
   Price Carousel (Full Width Below Images)
   ========================================================================== */
.yacht-price-carousel-section {
    margin-bottom: 40px;
}

.yacht-price-carousel-section h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--yolo-text);
    margin-bottom: 20px;
}

.price-carousel-container {
    position: relative;
    padding: 0 50px;
}

.price-carousel-slides {
    display: flex;
    gap: 15px;
    overflow-x: auto;
    scroll-behavior: smooth;
    padding: 10px 0;
    scrollbar-width: none;
    -ms-overflow-style: none;
}

.price-carousel-slides::-webkit-scrollbar {
    display: none;
}

.price-slide {
    min-width: 250px;
    flex-shrink: 0;
    text-align: center;
    padding: 20px 15px;
    border: 2px solid var(--yolo-border);
    border-radius: 8px;
    background: white;
    transition: all 0.3s ease;
    cursor: pointer;
}

.price-slide:hover,
.price-slide.active {
    border-color: var(--yolo-primary);
    box-shadow: 0 4px 12px rgba(30, 58, 138, 0.15);
}

.price-week {
    font-size: 13px;
    font-weight: 600;
    color: var(--yolo-text);
    margin-bottom: 8px;
}

.price-original .strikethrough {
    text-decoration: line-through;
    color: #9ca3af;
    font-size: 14px;
}

.price-discount-badge {
    background: #fef3c7;
    color: #92400e;
    padding: 4px 10px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 600;
    display: inline-block;
    margin: 8px 0;
}

.price-final {
    font-size: 24px;
    font-weight: 700;
    color: var(--yolo-success);
    margin-bottom: 12px;
}

.price-select-btn {
    width: 100%;
    padding: 10px;
    background: var(--yolo-primary);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.price-select-btn:hover {
    background: var(--yolo-primary-dark);
}

.price-carousel-prev,
.price-carousel-next {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: var(--yolo-primary);
    color: white;
    border: none;
    font-size: 24px;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    cursor: pointer;
    transition: background 0.3s ease;
    display: flex;
    align-items: center;
    justify-content: center;
}

.price-carousel-prev:hover,
.price-carousel-next:hover {
    background: var(--yolo-primary-dark);
}

.price-carousel-prev {
    left: 0;
}

.price-carousel-next {
    right: 0;
}

/* ==========================================================================
   Selected Price Display
   ========================================================================== */
.selected-price-display {
    background: var(--yolo-bg-light);
    border: 2px solid var(--yolo-border);
    border-radius: 8px;
    padding: 20px;
    text-align: center;
}

.selected-price-original {
    font-size: 14px;
    color: var(--yolo-text-muted);
    margin-bottom: 5px;
}

.selected-price-discount {
    background: #fef3c7;
    color: #92400e;
    font-size: 12px;
    font-weight: 600;
    padding: 4px 12px;
    border-radius: 4px;
    display: inline-block;
    margin-bottom: 10px;
}

.selected-price-final {
    font-size: 32px;
    font-weight: 700;
    color: var(--yolo-primary);
}

/* ==========================================================================
   Date Picker
   ========================================================================== */
.date-picker-section {
    position: relative;
    z-index: 100;
}

#dateRangePicker {
    width: 100%;
    padding: 14px;
    border: 2px solid var(--yolo-text);
    border-radius: 6px;
    font-size: 16px;
    font-weight: 500;
    text-align: center;
    cursor: pointer;
    background: white;
    transition: all 0.2s ease;
}

#dateRangePicker:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

#dateRangePicker:focus {
    outline: none;
    box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.2);
}

/* Litepicker overrides */
.litepicker {
    z-index: 9999 !important;
}

/* ==========================================================================
   Action Buttons
   ========================================================================== */
.btn-book-now {
    width: 100%;
    padding: 16px;
    background: var(--yolo-secondary);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 18px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.3s ease;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
}

.btn-book-now:hover {
    background: var(--yolo-secondary-dark);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(185, 28, 28, 0.3);
}

.btn-book-now .btn-main-text {
    font-size: 18px;
    font-weight: 700;
    letter-spacing: 1px;
}

.btn-book-now .btn-sub-text {
    font-size: 13px;
    font-weight: 500;
    opacity: 0.95;
}

.btn-request-quote {
    width: 100%;
    padding: 14px;
    background: var(--yolo-primary);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-request-quote:hover {
    background: var(--yolo-primary-dark);
    transform: translateY(-2px);
}

/* ==========================================================================
   Quote Form
   ========================================================================== */
.quote-form {
    margin-top: 20px;
    padding: 20px;
    background: var(--yolo-bg-light);
    border-radius: 8px;
}

.quote-form h4 {
    font-size: 18px;
    font-weight: 700;
    color: var(--yolo-text);
    margin: 0 0 20px 0;
    text-align: center;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px;
    margin-bottom: 10px;
}

@media (max-width: 576px) {
    .form-row {
        grid-template-columns: 1fr;
    }
}

.form-field input,
.form-field textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 4px;
    font-size: 14px;
    font-family: inherit;
}

.form-field input:focus,
.form-field textarea:focus {
    outline: none;
    border-color: var(--yolo-primary);
    box-shadow: 0 0 0 3px rgba(30, 58, 138, 0.1);
}

.btn-submit-quote {
    width: 100%;
    padding: 14px;
    background: var(--yolo-primary);
    color: white;
    border: none;
    border-radius: 6px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
}

.btn-submit-quote:hover {
    background: var(--yolo-primary-dark);
}

/* ==========================================================================
   Description Section
   ========================================================================== */
.yacht-description-section {
    margin-bottom: 40px;
}

.yacht-description-section h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--yolo-text);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 3px solid var(--yolo-primary);
}

.description-toggle {
    background: none;
    border: none;
    color: var(--yolo-primary);
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    padding: 10px 0;
    text-decoration: underline;
    transition: color 0.2s ease;
}

.description-toggle:hover {
    color: var(--yolo-primary-dark);
}

/* ==========================================================================
   Equipment Section
   ========================================================================== */
.yacht-equipment-section {
    margin-bottom: 40px;
}

.yacht-equipment-section h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--yolo-text);
    margin-bottom: 20px;
    padding-bottom: 10px;
    border-bottom: 3px solid var(--yolo-primary);
}

.equipment-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 12px;
}

.equipment-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    background: var(--yolo-bg-light);
    border-radius: 6px;
    font-size: 14px;
    color: #374151;
}

.equipment-item i {
    color: #3b82f6;
    font-size: 18px;
    min-width: 24px;
    text-align: center;
}

/* ==========================================================================
   Map Section
   ========================================================================== */
.yacht-map-section {
    margin-bottom: 40px;
}

.yacht-map-section h3 {
    font-size: 1.5rem;
    font-weight: 700;
    color: var(--yolo-text);
    margin-bottom: 20px;
}

/* ==========================================================================
   Policy Sections (Cancellation, Deposit, Check-in)
   ========================================================================== */
.yacht-cancellation-policy,
.deposit-section,
.checkin-section {
    margin-bottom: 30px;
    border-radius: 12px;
    padding: 30px;
}

.yacht-cancellation-policy {
    background: var(--yolo-bg-light);
}

.deposit-section {
    background: #f0fdf4;
}

.checkin-section {
    background: #eff6ff;
}

.yacht-cancellation-policy h3,
.deposit-section h3,
.checkin-section h3 {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 20px;
    color: #111827;
}

.policy-item,
.checkin-item {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 15px;
    background: white;
    border-radius: 8px;
    border-left: 4px solid #3b82f6;
    margin-bottom: 15px;
}

.policy-icon,
.checkin-icon {
    font-size: 24px;
    flex-shrink: 0;
}

.policy-note {
    padding: 15px;
    background: #fef3c7;
    border-radius: 8px;
    border-left: 4px solid var(--yolo-warning);
    margin-top: 15px;
}

.policy-note p {
    margin: 0;
    font-size: 14px;
    color: #92400e;
}

.deposit-amount {
    background: white;
    border-radius: 12px;
    padding: 25px;
    text-align: center;
    border: 2px solid #10b981;
    margin-bottom: 20px;
}

.amount-value {
    font-size: 36px;
    font-weight: 700;
    color: var(--yolo-success);
}

.checkin-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.checkin-label {
    font-size: 13px;
    color: var(--yolo-text-muted);
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 5px;
}

.checkin-value {
    font-size: 18px;
    font-weight: 600;
    color: #111827;
}

/* ==========================================================================
   Responsive Adjustments
   ========================================================================== */
@media (max-width: 991.98px) {
    /* Mobile: disable sticky sidebar */
    .yacht-booking-section {
        position: static !important;
        max-height: none !important;
        overflow-y: visible !important;
    }
}

@media (max-width: 767.98px) {
    .yacht-cancellation-policy,
    .deposit-section,
    .checkin-section {
        padding: 20px;
    }
    
    .policy-item,
    .checkin-item {
        flex-direction: column;
        gap: 8px;
    }
    
    .amount-value {
        font-size: 28px;
    }
    
    .checkin-grid {
        grid-template-columns: 1fr;
    }
    
    .price-carousel-container {
        padding: 0 35px;
    }
    
    .price-slide {
        min-width: 200px;
    }
}

/* ==========================================================================
   Print Styles
   ========================================================================== */
@media print {
    .yacht-booking-section,
    .btn-book-now,
    .btn-request-quote,
    .quote-form,
    .carousel-prev,
    .carousel-next,
    .carousel-dots {
        display: none !important;
    }
    
    .yacht-main-grid {
        display: block !important;
    }
}

/* ==========================================================================
   Accessibility
   ========================================================================== */
.btn-book-now:focus,
.btn-request-quote:focus,
.price-select-btn:focus,
.btn-submit-quote:focus {
    outline: 2px solid var(--yolo-primary);
    outline-offset: 2px;
}

/* Reduce motion for users who prefer it */
@media (prefers-reduced-motion: reduce) {
    .carousel-slide,
    .price-slide,
    .btn-book-now,
    .btn-request-quote,
    #dateRangePicker {
        transition: none;
    }
}
</style>
