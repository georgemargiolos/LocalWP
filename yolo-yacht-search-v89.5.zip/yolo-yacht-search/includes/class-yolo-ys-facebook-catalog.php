<?php
/**
 * Facebook Product Catalog Feed Generator
 * 
 * @package YOLO_Yacht_Search
 * @since 86.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class YOLO_YS_Facebook_Catalog {
    
    /**
     * All company IDs for catalog (YOLO + Partners)
     * v86.4: Now includes YOLO company alongside partners
     */
    private $catalog_company_ids;
    
    /**
     * Constructor - load YOLO + partner companies from settings
     * v86.4: Combined YOLO and partners for unified catalog
     */
    public function __construct() {
        // Get YOLO company ID
        $yolo_company = intval(get_option('yolo_ys_my_company_id', 7850));
        
        // Get partner company IDs
        $friend_companies = get_option('yolo_ys_friend_companies', '4366,3604,6711');
        $partners = array_filter(array_map('intval', array_map('trim', explode(',', $friend_companies))));
        
        // Fallback for partners if empty
        if (empty($partners)) {
            $partners = array(4366, 3604, 6711);
        }
        
        // Combine: YOLO + Partners for catalog
        $this->catalog_company_ids = array_unique(array_merge(array($yolo_company), $partners));
    }
    
    /**
     * Brand mapping for models that don't include brand prefix
     */
    private $brand_mapping = array(
        // Beneteau family
        'Oceanis' => 'Beneteau',
        'First' => 'Beneteau',
        
        // Jeanneau family
        'Sun Odyssey' => 'Jeanneau',
        'Sun Fast' => 'Jeanneau',
        'Merry Fisher' => 'Jeanneau',
        
        // Fountaine Pajot family
        'Salina' => 'Fountaine Pajot',
        'Saba' => 'Fountaine Pajot',
        'Isla' => 'Fountaine Pajot',
        'Lucia' => 'Fountaine Pajot',
        'Elba' => 'Fountaine Pajot',
        'Astrea' => 'Fountaine Pajot',
        'Alegria' => 'Fountaine Pajot',
        'Saona' => 'Fountaine Pajot',
        'Tanna' => 'Fountaine Pajot',
        'Aura' => 'Fountaine Pajot',
        
        // Lagoon (Beneteau Group)
        'Lagoon' => 'Lagoon',
        
        // Other common models
        'Dufour' => 'Dufour',
        'Bavaria' => 'Bavaria',
        'Hanse' => 'Hanse',
        'Elan' => 'Elan',
        'Bali' => 'Bali',
        'Catana' => 'Catana',
        'Nautitech' => 'Nautitech',
        'Leopard' => 'Leopard',
        'Azimut' => 'Azimut',
        'Sunseeker' => 'Sunseeker',
        'Princess' => 'Princess',
        'Excess' => 'Excess',
        'Moody' => 'Moody',
        'Dehler' => 'Dehler',
        'Hallberg-Rassy' => 'Hallberg-Rassy',
        'X-Yachts' => 'X-Yachts',
        'Grand Soleil' => 'Grand Soleil',
        'More' => 'More',
    );
    
    /**
     * Extract brand from model name
     * 
     * @param string $model The yacht model name
     * @return string The brand name
     */
    public function extract_brand_from_model($model) {
        if (empty($model)) {
            return 'Other';
        }
        
        $model = trim($model);
        
        // Check brand mapping (covers most cases)
        foreach ($this->brand_mapping as $prefix => $brand) {
            if (stripos($model, $prefix) === 0) {
                return $brand;
            }
        }
        
        // If model contains a number, the word before it might be the brand
        // e.g., "Bavaria C42" -> "Bavaria"
        if (preg_match('/^([A-Za-z\-]+)\s/', $model, $matches)) {
            $potential_brand = trim($matches[1]);
            // v86.2 FIX: Check if it's a known brand (either as key or value)
            if (array_key_exists($potential_brand, $this->brand_mapping)) {
                return $this->brand_mapping[$potential_brand];
            }
            if (in_array($potential_brand, $this->brand_mapping)) {
                return $potential_brand;
            }
        }
        
        return 'Other';
    }
    
    /**
     * Determine boat type from model name
     * 
     * @param string $model The yacht model name
     * @return string Sailboat or Catamaran
     */
    public function get_boat_type($model) {
        $catamaran_brands = array(
            'Lagoon', 'Fountaine Pajot', 'Bali', 'Catana', 'Nautitech', 
            'Leopard', 'Excess', 'Saona', 'Saba', 'Lucia', 'Isla', 
            'Elba', 'Astrea', 'Alegria', 'Tanna', 'Aura', 'Salina'
        );
        
        foreach ($catamaran_brands as $cat_brand) {
            if (stripos($model, $cat_brand) !== false) {
                return 'Catamaran';
            }
        }
        
        return 'Sailboat';
    }
    
    /**
     * Update starting_from_price for all partner boats based on minimum offer price
     * Called after offers sync
     */
    public function update_partner_starting_prices() {
        global $wpdb;
        
        // v86.4: Early return if no companies configured
        if (empty($this->catalog_company_ids)) {
            error_log('YOLO Facebook Catalog: No companies configured for price update');
            return 0;
        }
        
        $yachts_table = $wpdb->prefix . 'yolo_yachts';
        $prices_table = $wpdb->prefix . 'yolo_yacht_prices';
        $custom_table = $wpdb->prefix . 'yolo_yacht_custom_settings';
        
        // v87.0: Build company IDs directly into query
        $company_ids_escaped = implode(',', array_map('intval', $this->catalog_company_ids));
        
        // v87.0 FIX: Remove date filter - use minimum price from ANY offer (past or future)
        // The "starting from" price is an indicative price, valid regardless of specific dates
        $sql = "SELECT 
                y.id as yacht_id,
                y.model,
                MIN(p.price) as min_price
            FROM {$yachts_table} y
            INNER JOIN {$prices_table} p ON CAST(y.id AS CHAR) = p.yacht_id
            WHERE y.company_id IN ({$company_ids_escaped})
            AND (y.status = 'active' OR y.status IS NULL)
            AND p.price > 0
            GROUP BY y.id, y.model
            HAVING MIN(p.price) > 0";
        
        $results = $wpdb->get_results($sql);
        
        if (empty($results)) {
            error_log('YOLO Facebook Catalog: No partner boats with prices found');
            return 0;
        }
        
        $updated_count = 0;
        
        foreach ($results as $row) {
            if (empty($row->min_price) || $row->min_price <= 0) {
                continue;
            }
            
            // Check if custom settings row exists
            $existing = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$custom_table} WHERE yacht_id = %s",
                $row->yacht_id
            ));
            
            if ($existing) {
                // Update existing row
                $wpdb->update(
                    $custom_table,
                    array('starting_from_price' => floatval($row->min_price)),
                    array('yacht_id' => $row->yacht_id),
                    array('%f'),
                    array('%s')
                );
            } else {
                // Insert new row
                $wpdb->insert(
                    $custom_table,
                    array(
                        'yacht_id' => $row->yacht_id,
                        'starting_from_price' => floatval($row->min_price)
                    ),
                    array('%s', '%f')
                );
            }
            
            $updated_count++;
        }
        
        error_log("YOLO Facebook Catalog: Updated starting prices for {$updated_count} partner boats");
        
        // Update last catalog sync time
        update_option('yolo_ys_last_fb_catalog_update', current_time('mysql'));
        
        return $updated_count;
    }
    
    /**
     * Get partner boats for catalog
     * 
     * @return array Array of yacht objects
     */
    public function get_partner_boats() {
        global $wpdb;
        
        // v86.4: Early return if no companies configured
        if (empty($this->catalog_company_ids)) {
            return array();
        }
        
        $yachts_table = $wpdb->prefix . 'yolo_yachts';
        $custom_table = $wpdb->prefix . 'yolo_yacht_custom_settings';
        
        // v86.9: Build company IDs directly into query (simpler, more reliable)
        $company_ids_escaped = implode(',', array_map('intval', $this->catalog_company_ids));
        
        // v87.2: Use LEFT JOIN with COALESCE (same as get_stats which works)
        // CAST y.id AS CHAR to ensure yacht_id is string for image lookup
        $sql = "SELECT 
                CAST(y.id AS CHAR) as yacht_id,
                y.name,
                y.model,
                y.slug,
                y.description,
                y.cabins,
                y.berths,
                y.home_base,
                y.year_of_build,
                y.company_id,
                COALESCE(c.starting_from_price, 0) as starting_from_price,
                COALESCE(c.custom_description, '') as custom_description
            FROM {$yachts_table} y
            LEFT JOIN {$custom_table} c ON CAST(y.id AS CHAR) = c.yacht_id
            WHERE y.company_id IN ({$company_ids_escaped})
            AND (y.status = 'active' OR y.status IS NULL)
            AND COALESCE(c.starting_from_price, 0) > 0
            ORDER BY y.model ASC";
        
        return $wpdb->get_results($sql);
    }
    
    /**
     * Get images for a yacht
     * v87.2: Ensure yacht_id is string for consistent matching
     * 
     * @param mixed $yacht_id The yacht ID (will be cast to string)
     * @return array Array of image URLs
     */
    public function get_yacht_images($yacht_id) {
        global $wpdb;
        
        // v87.2: Ensure yacht_id is string for consistent matching
        $yacht_id = (string) $yacht_id;
        
        $images_table = $wpdb->prefix . 'yolo_yacht_images';
        $custom_media_table = $wpdb->prefix . 'yolo_yacht_custom_media';
        $custom_settings_table = $wpdb->prefix . 'yolo_yacht_custom_settings';
        $yachts_table = $wpdb->prefix . 'yolo_yachts';
        
        // First check if yacht uses custom media
        $use_custom = $wpdb->get_var($wpdb->prepare(
            "SELECT use_custom_media FROM {$custom_settings_table} WHERE yacht_id = %s",
            $yacht_id
        ));
        
        if ($use_custom) {
            // Get custom media images
            $custom_images = $wpdb->get_col($wpdb->prepare(
                "SELECT media_url FROM {$custom_media_table} WHERE yacht_id = %s AND media_type = 'image' ORDER BY sort_order ASC LIMIT 11",
                $yacht_id
            ));
            
            if (!empty($custom_images)) {
                return $custom_images;
            }
        }
        
        // Fall back to API images
        $api_images = $wpdb->get_col($wpdb->prepare(
            "SELECT image_url FROM {$images_table} WHERE yacht_id = %s ORDER BY sort_order ASC LIMIT 11",
            $yacht_id
        ));
        
        // v87.2: If no images in images table, check main image in yachts table
        if (empty($api_images)) {
            $main_image = $wpdb->get_var($wpdb->prepare(
                "SELECT image_url FROM {$yachts_table} WHERE CAST(id AS CHAR) = %s AND image_url IS NOT NULL AND image_url != ''",
                $yacht_id
            ));
            if ($main_image) {
                return array($main_image);
            }
        }
        
        return $api_images ?: array();
    }
    
    /**
     * Generate the CSV feed content
     * v87.4: Added proper descriptions, product_type, google_product_category
     * 
     * @return string CSV content
     */
    public function generate_feed() {
        $boats = $this->get_partner_boats();
        
        // CSV Header - v87.4: Added product_type and google_product_category
        $csv_lines = array();
        $csv_lines[] = 'id,title,description,price,link,image_link,additional_image_link,brand,availability,condition,product_type,google_product_category,custom_label_0,custom_label_1,custom_label_2,custom_label_3,custom_label_4';
        
        if (empty($boats)) {
            return implode("\n", $csv_lines);
        }
        
        $site_url = home_url();
        $yacht_base_url = $site_url . '/yacht/';
        
        foreach ($boats as $boat) {
            // Get images
            $images = $this->get_yacht_images($boat->yacht_id);
            
            // Skip if no images
            if (empty($images)) {
                continue;
            }
            
            // Primary image
            $primary_image = $images[0];
            
            // Additional images (up to 10) - v87.4: Ensure proper formatting
            $additional_images = array_slice($images, 1, 10);
            $additional_images_str = implode(',', $additional_images);
            
            // Build title: Name - Model (v87.3 fix)
            $yacht_name = trim($boat->name);
            $yacht_model = trim($boat->model);
            $title = $yacht_name . ' - ' . $yacht_model;
            
            // v87.4: Generate proper description if empty
            $description = !empty($boat->custom_description) ? $boat->custom_description : $boat->description;
            $description = wp_strip_all_tags($description);
            $description = preg_replace('/\s+/', ' ', $description);
            $description = trim($description);
            
            // If description is empty, generate one from yacht data
            if (empty($description)) {
                $description = $this->generate_description($boat, $yacht_name, $yacht_model);
            }
            
            $description = substr($description, 0, 5000); // Facebook limit
            
            // Price
            $price = number_format($boat->starting_from_price, 2, '.', '') . ' EUR';
            
            // Link - v86.2 FIX: Add fallback for empty slugs
            if (!empty($boat->slug)) {
                $link = $yacht_base_url . $boat->slug . '/';
            } else {
                $link = home_url('/yacht-details/?yacht_id=' . $boat->yacht_id);
            }
            
            // Brand
            $brand = $this->extract_brand_from_model($yacht_model);
            
            // Boat type
            $boat_type = $this->get_boat_type($yacht_model);
            
            // v87.4: Product type for Facebook (hierarchical category)
            $product_type = 'Vehicles & Parts > Vehicles > Watercraft > ' . $boat_type . 's';
            
            // v87.4: Google Product Category for boats
            // 3564 = Vehicles & Parts > Vehicles > Watercraft > Sailboats
            // 3563 = Vehicles & Parts > Vehicles > Watercraft > Motor Boats (using for catamarans)
            $google_category = ($boat_type === 'Catamaran') ? '3563' : '3564';
            
            // Custom labels with meaningful data
            $custom_label_0 = $boat_type; // Sailboat/Catamaran
            $custom_label_1 = !empty($boat->cabins) ? $boat->cabins . ' Cabins' : '';
            $custom_label_2 = !empty($boat->berths) ? $boat->berths . ' Berths' : '';
            $custom_label_3 = !empty($boat->home_base) ? $boat->home_base : '';
            $custom_label_4 = !empty($boat->year_of_build) ? 'Built ' . $boat->year_of_build : '';
            
            // Build CSV row
            $row = array(
                $this->csv_escape($boat->yacht_id, true),  // v86.2: Force quote large numbers
                $this->csv_escape($title),
                $this->csv_escape($description),
                $this->csv_escape($price),
                $this->csv_escape($link),
                $this->csv_escape($primary_image),
                $this->csv_escape($additional_images_str, true), // v87.4: Force quote for comma-separated URLs
                $this->csv_escape($brand),
                'in stock',
                'used',
                $this->csv_escape($product_type),
                $this->csv_escape($google_category),
                $this->csv_escape($custom_label_0),
                $this->csv_escape($custom_label_1),
                $this->csv_escape($custom_label_2),
                $this->csv_escape($custom_label_3),
                $this->csv_escape($custom_label_4),
            );
            
            $csv_lines[] = implode(',', $row);
        }
        
        return implode("\n", $csv_lines);
    }
    
    /**
     * Generate a description from yacht data
     * v87.4: New method to create descriptions when none exists
     * 
     * @param object $boat Boat data object
     * @param string $yacht_name Yacht name
     * @param string $yacht_model Yacht model
     * @return string Generated description
     */
    private function generate_description($boat, $yacht_name, $yacht_model) {
        $brand = $this->extract_brand_from_model($yacht_model);
        $boat_type = $this->get_boat_type($yacht_model);
        
        $parts = array();
        
        // Opening line
        $parts[] = "Charter the {$yacht_name}, a beautiful {$brand} {$yacht_model} {$boat_type} available for sailing holidays in Greece.";
        
        // Specs
        $specs = array();
        if (!empty($boat->cabins)) {
            $specs[] = $boat->cabins . ' cabin' . ($boat->cabins > 1 ? 's' : '');
        }
        if (!empty($boat->berths)) {
            $specs[] = 'sleeps ' . $boat->berths . ' guests';
        }
        if (!empty($boat->year_of_build)) {
            $specs[] = 'built in ' . $boat->year_of_build;
        }
        
        if (!empty($specs)) {
            $parts[] = 'This yacht features ' . implode(', ', $specs) . '.';
        }
        
        // Location
        if (!empty($boat->home_base)) {
            $parts[] = "Based at {$boat->home_base}, perfect for exploring the Ionian islands.";
        }
        
        // Call to action
        $parts[] = 'Book now for an unforgettable sailing experience with YOLO Charters.';
        
        return implode(' ', $parts);
    }
    
    /**
     * Escape value for CSV
     * v86.2 FIX: Added force_quote parameter for large numbers
     * 
     * @param string $value The value to escape
     * @param bool $force_quote Force quoting (for large numbers that Excel might misinterpret)
     * @return string Escaped value
     */
    private function csv_escape($value, $force_quote = false) {
        if ($value === null || $value === '') {
            return '""';
        }
        
        $value = (string) $value;
        $value = str_replace('"', '""', $value);
        
        // v86.2 FIX: Always quote if forced (for long numbers like yacht IDs)
        if ($force_quote || strpos($value, ',') !== false || strpos($value, '"') !== false || strpos($value, "\n") !== false) {
            return '"' . $value . '"';
        }
        
        return $value;
    }
    
    /**
     * Output the feed with proper headers
     */
    public function output_feed() {
        // Set headers for CSV download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: inline; filename="facebook-yacht-catalog.csv"');
        header('Cache-Control: no-cache, must-revalidate');
        header('Pragma: no-cache');
        
        echo $this->generate_feed();
        exit;
    }
    
    /**
     * Get the feed URL
     * 
     * @return string The feed URL
     */
    public function get_feed_url() {
        return home_url('/facebook-catalog-feed/');
    }
    
    /**
     * Get catalog stats for admin display
     * 
     * @return array Stats array
     */
    public function get_stats() {
        global $wpdb;
        
        $yachts_table = $wpdb->prefix . 'yolo_yachts';
        $custom_table = $wpdb->prefix . 'yolo_yacht_custom_settings';
        
        // v86.9: Build company IDs directly into query (simpler, more reliable)
        $company_ids_escaped = implode(',', array_map('intval', $this->catalog_company_ids));
        
        // Total catalog boats (YOLO + Partners)
        $total = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$yachts_table} WHERE company_id IN ({$company_ids_escaped}) AND (status = 'active' OR status IS NULL)"
        );
        
        // Catalog boats with prices - v86.11: Use CAST for consistency
        $with_prices = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$yachts_table} y LEFT JOIN {$custom_table} c ON CAST(y.id AS CHAR) = c.yacht_id WHERE y.company_id IN ({$company_ids_escaped}) AND (y.status = 'active' OR y.status IS NULL) AND COALESCE(c.starting_from_price, 0) > 0"
        );
        
        $last_update = get_option('yolo_ys_last_fb_catalog_update', 'Never');
        
        return array(
            'total_partner_boats' => intval($total),
            'boats_with_prices' => intval($with_prices),
            'last_update' => $last_update,
        );
    }
}
