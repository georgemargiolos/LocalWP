Logo placeholder - replace with actual YOLO Charters logo
